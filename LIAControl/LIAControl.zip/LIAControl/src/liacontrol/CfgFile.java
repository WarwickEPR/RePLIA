/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liacontrol;

import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author stimp
 */
public class CfgFile {
    
    public void create(String ip, String file, String demod, String modamp, String tc, String phase, String rate, String vstart, String vstop, String tsweep, String daca, String dacb, String mode) throws IOException{
        
        String[] fstub = file.split("\\.");
        String nfile = fstub[0] + ".lip";
        System.out.println("Saving experiment parameters to " + nfile);
        FileWriter fw = new FileWriter(nfile);
        fw.write("LIA Host address: ");
        fw.write(ip);
        fw.write(System.lineSeparator());
        fw.write("Demodulation Frequency (Hz): ");
        fw.write(demod);
        fw.write(System.lineSeparator());
        fw.write("Modulation amplitude (LIA reference)(V): ");
        fw.write(modamp);
        fw.write(System.lineSeparator());
        fw.write("Time constant (sec): ");
        fw.write(tc);
        fw.write(System.lineSeparator());
        fw.write("Modulation phase (LIA reference)(deg): ");
        fw.write(phase);
        fw.write(System.lineSeparator());
        fw.write("Sampling rate (S/s): ");
        fw.write(rate);
        fw.write(System.lineSeparator());
        fw.write("LIA Sweep start (V): ");
        fw.write(vstart);
        fw.write(System.lineSeparator());
        fw.write("LIA Sweep stop (V): ");
        fw.write(vstop);
        fw.write(System.lineSeparator());
        fw.write("LIA Sweep length (sec): ");
        fw.write(tsweep);
        fw.write(System.lineSeparator());
        fw.write("DAC A Multiplier: ");
        fw.write(daca);
        fw.write(System.lineSeparator());
        fw.write("DAC B Multiplier: ");
        fw.write(dacb);
        fw.write(System.lineSeparator());
        fw.write("Mode String (Reversed): ");
        fw.write(mode);
        fw.write(System.lineSeparator());
        fw.close();
    }
    
}
