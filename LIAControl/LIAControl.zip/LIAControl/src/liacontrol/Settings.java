/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liacontrol;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

/**
 *
 * @author stimp
 */
public class Settings {
    
    public int begin(String ip, String user, String pass) throws JSchException, IOException{
        Main.outputArea.setText("");
        String command = "./tmp/channels/startall.sh";
        System.out.println(command);
        JSch jsch = new JSch();
        Session session = jsch.getSession(user, ip, 22);
        session.setPassword(pass);
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config);
        session.connect();

        ChannelExec channel = (ChannelExec) session.openChannel("exec");
        BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
        channel.setCommand(command);
        channel.connect();

        String msg = null;
        while ((msg = in.readLine()) != null) {
            Main.outputArea.append(msg);
            Main.outputArea.append(System.lineSeparator());
        }

        channel.disconnect();
        session.disconnect();
        
        return 1;
    
    }
    
    public void initialise(String ip, String user, String pass) throws JSchException, IOException{
        Main.outputArea.setText("");
        String command = "/root/tmp/channels/initsetup.sh";
        System.out.println(command);
        JSch jsch = new JSch();
        Session session = jsch.getSession(user, ip, 22);
        session.setPassword(pass);
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config);
        session.connect();

        ChannelExec channel = (ChannelExec) session.openChannel("exec");
        BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
        channel.setCommand(command);
        channel.connect();

        String msg = null;
        while ((msg = in.readLine()) != null) {
            Main.outputArea.append(msg);
            Main.outputArea.append(System.lineSeparator());
        }

        channel.disconnect();
        session.disconnect();
    
    }

    public void send(String ip, String user, String pass, String f, String t, String m, String vStart, String vStop, String tSweep, String a, String da, String db, String p, String r) throws JSchException, IOException {
        Main.outputArea.setText("");
        String command = "/root/tmp/channels/settings f " + f + " t " + t + " m " + m + " s " + vStart + " " + vStop + " " + tSweep + " a " + a + " d " + da + " " + db + " p " + p + " r " + r;
        System.out.println(command);
        JSch jsch = new JSch();
        Session session = jsch.getSession(user, ip, 22);
        session.setPassword(pass);
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config);
        session.connect();

        ChannelExec channel = (ChannelExec) session.openChannel("exec");
        BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
        channel.setCommand(command);
        channel.connect();

        String msg = null;
        while ((msg = in.readLine()) != null) {
            Main.outputArea.append(msg);
            Main.outputArea.append(System.lineSeparator());
        }

        channel.disconnect();
        session.disconnect();
    }

}
