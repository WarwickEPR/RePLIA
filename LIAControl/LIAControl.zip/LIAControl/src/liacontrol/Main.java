/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liacontrol;

import com.jcraft.jsch.JSchException;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author stimp
 */
public class Main extends javax.swing.JFrame {

    /**
     * Creates new form Main
     */
    public Main() throws IOException {
        initComponents();
        this.setIconImage(Toolkit.getDefaultToolkit().getImage("logorpliaTP.png"));
        presetBox.setMaximumRowCount(16);
        presetBox.setSelectedIndex(10);
        presetBtn.setSelected(true);
        customBtn.setSelected(false);
        getDataBtn.setEnabled(false);
        //plotBtn.setEnabled(false);
        new Config().read();

        //Set tooltips
        modeHelp.setToolTipText("<html>Set modes of operation for Red Pitaya LIA.<br>\n"
                + " Must contain a string of 12 digits (1 or 0). <br>\n"
                + "From Left to right, digits are as follows:<html><br>\n"
                + "<br>\n"
                + "LIA Mode:                            0 for master, 1 for slave.<br>\n"
                + "No. of inputs:                       0 for single, 1 for dual.<br>\n"
                + "Output type:                         0 for X&Y, 1 for Amp&Phase.<br>\n"
                + "Send sync signal?                    0 for no, 1 for yes.<br>\n"
                + "Sweep on DAC B?:                     0 for no, 1 for yes.<br>\n"
                + "Reference on top of sweep?:          0 for no, 1 for yes.<br>\n"
                + "Drop at start of sweep an DAC B?:    0 for no, 1 for yes.<br>\n"
                + "Output Mode:                         0 for X/R or 1 for Y/Phase.<br>\n"
                + "Reference Waveform:                  0 for sine, 1 for square.<br>\n"
                + "Sweep Output:                        0 for sweep, 1 for constant value.<br>\n"
                + "Frequency double reference wave?:    0 for no, 1 for yes.<br>\n"
                + "Sweep counter:                       0 for internal, 1 for external.<br>\n"
                + "<br>\n"
                + "Ensure that the mode string contains all twelve digits.");
        liaHelp.setToolTipText("<html>Set the IP, username and user password of the Red Pitaya.<br>\n"
                + "Note that this is specific to the Red Pitaya computing board and<br>\n"
                + "is unrelated to the client computer.</html>");
        fileHelp.setToolTipText("<html>Choose a local file for storing remote data.<br>\n"
                + "<br>\n"
                + "Note: A file must be chosen before remote data can be transferred.<br>\n"
                + "All data from all channels will be transferred into a single file.<br>\n"
                + "Remote file will be translated from binary format to human readable format.<br>"
                + "File type is csv.</html>");
        frequencyHelp.setToolTipText("<html>Set the modulation frequency of the lock-in.<br>\n"
                + "Note that when using the Red Pitaya to provide<br>\n"
                + "the reference frequency, this will necessarily<br>\n"
                + "equal the demodulation frequency.<br>\n"
                + "<br>\n"
                + "To use a preset frequency, choose from the drop<br>\n"
                + "down box and ensure that the 'Preset' box is ticked.<br>\n"
                + "<br>\n"
                + "To use the custom box, enter a frequency value<br>\n"
                + "in the text area and ensure the 'custom' box is<br>\n"
                + "ticked. Frequencies may be entered verbosely,<br>\n"
                + "e.g. 1300, or may be entered in scientific notation,<br>\n"
                + "e.g. 1.3e3 .</html>");
        tcHelp.setToolTipText("<html>Enter a value for the time constant (averaging period) in seconds.<br>\n"
                + "<br>\n"
                + "Note that when sweeping values, the time constant should be<br>\n"
                + "small enough that individual spectral features are more than 10<br>\n"
                + "times the size of the averaging period.</html>");
        modAmpHelp.setToolTipText("<html>Set the modulation amplitude in Volts.<br>\n"
                + "<br>\n"
                + "This will only affect the outgoing reference signal and does<br>\n"
                + "not have any effect on externally referenced inputs.</html>");
        rateHelp.setToolTipText("<html>Set the Red Pitaya LIA sampling frequency in Hz / Samples per second.<br>\n"
                + "<br>\n"
                + "Be aware that plotting software may not match this sampling rate.<br>\n"
                + "Always adjust software sampling rates when troubleshooting outputs.</html>");
        phaseHelp.setToolTipText("<html>Set the phase lead of the modulation output in degrees (<sup>o</sup>). This does not affect inputs.</html>");
        sweepHelp.setToolTipText("<html>Set the parameters of the reference sweep.<br>\n"
                + "<br>\n"
                + "V<sub>start</sub> is the low voltage start of the sweep in Volts.<br>\n"
                + "Must not go lower than -1 V.<br>\n"
                + "V<sub>end</sub> is the upper limiot of the sweep in volts. Must not<br>\n"
                + "go above 1 V.<br>\n"
                + "t<sub>sweep</sub> is the sweep time in seconds.</html>");
        dacHelp.setToolTipText("<html>Set the value of the DAC multipliers fior channels A and B.<br>\n"
                + "Minimum (now amplification) is 1. Maximum is 200.<br>\n"
                + "<br>\n"
                + "Maximum can be set to 2000 on Red Pitaya command line.</html>");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator4 = new javax.swing.JSeparator();
        jLabel20 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        customText = new javax.swing.JTextField();
        presetBox = new javax.swing.JComboBox<>();
        presetBtn = new javax.swing.JCheckBox();
        customBtn = new javax.swing.JCheckBox();
        jLabel2 = new javax.swing.JLabel();
        tcText = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        modAmpText = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        rateText = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel8 = new javax.swing.JLabel();
        phaseText = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        modeText = new javax.swing.JTextField();
        applyBtn = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        ipText = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        userText = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        passText = new javax.swing.JPasswordField();
        jSeparator8 = new javax.swing.JSeparator();
        modeHelp = new javax.swing.JLabel();
        liaHelp = new javax.swing.JLabel();
        tcHelp = new javax.swing.JLabel();
        frequencyHelp = new javax.swing.JLabel();
        modAmpHelp = new javax.swing.JLabel();
        rateHelp = new javax.swing.JLabel();
        phaseHelp = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        vStartText = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        vStopText = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        tSweepText = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        sweepHelp = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        dacAText = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        dacBText = new javax.swing.JTextField();
        jSeparator6 = new javax.swing.JSeparator();
        dacHelp = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        outputArea = new javax.swing.JTextArea();
        localFileText = new javax.swing.JTextField();
        chooseBtn = new javax.swing.JButton();
        getDataBtn = new javax.swing.JButton();
        fileHelp = new javax.swing.JLabel();
        plotBtn = new javax.swing.JButton();

        jLabel20.setText("jLabel20");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("RPLIA Control");

        jLabel1.setText("Demodulation Frequency (Hz):");

        customText.setText("1e3");
        customText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customTextActionPerformed(evt);
            }
        });

        presetBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1 Hz", "10 Hz", "50 Hz", "100 Hz", "500 Hz", "1 kHz", "2 kHz", "3 kHz", "4 kHz", "5 kHz", "10 kHz", "20 kHz", "30 kHz", "40 kHz", "50 kHz", "100 kHz", "200 kHz", "300 kHz", "400 kHz", "500 kHz", "1 MHz", "2 MHz", "3 MHz", "4 MHz", "5 MHz", "10 MHz", "20 MHz", "30 MHz", "40 MHz", "50 MHz", "100 MHz", " " }));

        presetBtn.setText("Preset");
        presetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                presetBtnActionPerformed(evt);
            }
        });

        customBtn.setText("Custom");
        customBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customBtnActionPerformed(evt);
            }
        });

        jLabel2.setText("Time Constant:");

        tcText.setText("0.001");

        jLabel3.setText("s");

        jLabel4.setText("Modulation Amplitude (V):");

        modAmpText.setText("0.02");

        jLabel5.setText("V");

        jLabel6.setText("Sampling Rate:");

        rateText.setText("2e4");

        jLabel7.setText("S/s");

        jLabel8.setText("Modulation Phase:");

        phaseText.setText("0");

        jLabel10.setText("<html><sup>o</sup></html>");

        jLabel9.setText("Mode String:");

        modeText.setText("011000000000");

        applyBtn.setText("Apply");
        applyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                applyBtnActionPerformed(evt);
            }
        });

        jButton2.setText("Defaults");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel11.setText("LIA IP:");

        ipText.setText("137.205.214.233");

        jLabel12.setText("User:");

        userText.setText("root");

        jLabel13.setText("Password:");

        passText.setText("nvmag");

        modeHelp.setText(" ? ");
        modeHelp.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        liaHelp.setText(" ? ");
        liaHelp.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tcHelp.setText(" ? ");
        tcHelp.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        frequencyHelp.setText(" ? ");
        frequencyHelp.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        modAmpHelp.setText(" ? ");
        modAmpHelp.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        rateHelp.setText(" ? ");
        rateHelp.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        phaseHelp.setText(" ? ");
        phaseHelp.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel14.setText("Sweep Parameters:");

        jLabel15.setText("<html>V<sub>start</sub<html>:");

        vStartText.setText("-0.95");

        jLabel16.setText("V");

        jLabel17.setText("<html>V<sub>end</sub>:</html>");

        vStopText.setText("0.95");

        jLabel18.setText("V");

        jLabel19.setText("<html>t<sub>sweep</sub>:</html>");

        tSweepText.setText("5");

        jLabel21.setText("s");

        sweepHelp.setText(" ? ");
        sweepHelp.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel23.setText("DAC Multipliers:");

        jLabel24.setText("A:");

        dacAText.setText("20");

        jLabel25.setText("B:");

        dacBText.setText("1");

        dacHelp.setText(" ? ");
        dacHelp.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        outputArea.setColumns(20);
        outputArea.setRows(5);
        jScrollPane1.setViewportView(outputArea);

        chooseBtn.setText("Choose file...");
        chooseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chooseBtnActionPerformed(evt);
            }
        });

        getDataBtn.setText("Get Remote Data");
        getDataBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getDataBtnActionPerformed(evt);
            }
        });

        fileHelp.setText(" ? ");
        fileHelp.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        plotBtn.setText("Plot Remote Data");
        plotBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                plotBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addComponent(jSeparator8)
                    .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator5)
                    .addComponent(jSeparator6, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButton2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(applyBtn))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(modeText, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(modeHelp))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel23)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel24)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dacAText, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel25)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dacBText, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(dacHelp)))
                        .addGap(22, 22, 22))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(passText))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(ipText, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                                    .addComponent(userText))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(liaHelp)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(localFileText, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(fileHelp))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(chooseBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(getDataBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(plotBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(29, 29, 29)
                                .addComponent(frequencyHelp))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(presetBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(customText, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(presetBtn)
                                    .addComponent(customBtn))
                                .addGap(24, 24, 24)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel4)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(modAmpText, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(tcText, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(phaseText, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(1, 1, 1)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(3, 3, 3)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(9, 9, 9)
                                        .addComponent(phaseHelp))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(modAmpHelp)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel5)
                                            .addGap(20, 20, 20))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(tcHelp)))))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(102, 102, 102))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(rateText, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7)
                            .addComponent(rateHelp))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(vStartText, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(vStopText, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tSweepText, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel18)
                                    .addComponent(jLabel21)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addGap(95, 95, 95)
                                .addComponent(sweepHelp)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(ipText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(liaHelp)
                            .addComponent(localFileText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(userText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(passText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(fileHelp)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(chooseBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(getDataBtn)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(plotBtn)
                .addGap(18, 18, 18)
                .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(frequencyHelp)
                    .addComponent(jLabel4)
                    .addComponent(modAmpHelp))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(presetBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(presetBtn)
                    .addComponent(modAmpText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(customText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(customBtn)
                    .addComponent(jLabel2)
                    .addComponent(tcText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(tcHelp))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phaseText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(phaseHelp))
                .addGap(9, 9, 9)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(rateHelp)
                    .addComponent(jLabel14)
                    .addComponent(sweepHelp))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(rateText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(vStartText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(vStopText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tSweepText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21))
                .addGap(22, 22, 22)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(jLabel24)
                    .addComponent(dacAText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25)
                    .addComponent(dacBText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dacHelp))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(modeHelp)
                    .addComponent(modeText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(applyBtn)
                    .addComponent(jButton2))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void customTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_customTextActionPerformed

    private void presetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_presetBtnActionPerformed
        customBtn.setSelected(false);
    }//GEN-LAST:event_presetBtnActionPerformed

    private void customBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customBtnActionPerformed
        presetBtn.setSelected(false);
    }//GEN-LAST:event_customBtnActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int reply = JOptionPane.showConfirmDialog(null, "Restore defaults? This cannot be undone.", "Continue...", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) {
            presetBox.setSelectedIndex(10);
            presetBtn.setSelected(true);
            customText.setText("1e3");
            customBtn.setSelected(false);
            tcText.setText("0.001");
            modAmpText.setText("0.02");
            rateText.setText("2e4");
            phaseText.setText("0");
            modeText.setText("011000000000");
            vStartText.setText("-0.95");
            vStopText.setText("0.95");
            tSweepText.setText("5");
            dacAText.setText("20");
            dacBText.setText("1");
        } else {

        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void applyBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_applyBtnActionPerformed
        try {
            String ip = ipText.getText();
            String user = userText.getText();
            String pass = passText.getText();
            String f;
            if (presetBtn.isSelected()) {
                f = presetBox.getSelectedItem().toString().split("\\ ")[0];
                String fs = presetBox.getSelectedItem().toString().split("\\ ")[1];
                if (fs.contains("k")) {
                    f = f + "000";
                } else if (fs.contains("M")) {
                    f = f + "000000";
                }
            } else {
                f = customText.getText();
            }
            String t = tcText.getText();
            String mx = modeText.getText();
            String[] ms = mx.split("");
            String m = "";
            for (int i = 11; i > -1; i--) {
                m = m + ms[i];
            }
            String vStart = vStartText.getText();
            String vStop = vStopText.getText();
            String tSweep = tSweepText.getText();
            String a = modAmpText.getText();
            String da = dacAText.getText();
            String db = dacBText.getText();
            String p = phaseText.getText();
            String r = rateText.getText();
            new Settings().send(ip, user, pass, f, t, m, vStart, vStop, tSweep, a, da, db, p, r);
            new Config().save(ip, user, pass, f, t, m, vStart, vStop, tSweep, a, da, db, p, r, localFileText.getText());
        } catch (JSchException | IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_applyBtnActionPerformed

    private void chooseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chooseBtnActionPerformed
        JFileChooser fc = new JFileChooser();
        File cd = new File(localFileText.getText());
        if(!cd.toString().equals("")){
            fc.setSelectedFile(cd);
        }
        fc.setMultiSelectionEnabled(false);
        FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV Files", "csv");
        fc.setFileFilter(filter);
        int result = fc.showSaveDialog(null);
        if (result == 0) {
            localFileText.setText(fc.getSelectedFile().toString());
            getDataBtn.setEnabled(true);
        }
    }//GEN-LAST:event_chooseBtnActionPerformed

    private void getDataBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getDataBtnActionPerformed
        new Thread(() -> {
            try {
                String f;
                if(presetBtn.isSelected()){
                    f = presetBox.getSelectedItem().toString();
                } else {
                    f = customText.getText();
                }
                new CfgFile().create(ipText.getText(), localFileText.getText(), f, modAmpText.getText(), tcText.getText(), phaseText.getText(), rateText.getText(), vStartText.getText(), vStopText.getText(), tSweepText.getText(), dacAText.getText(), dacBText.getText(), modeText.getText());
                outputArea.setText("");
                outputArea.append("Working...");
                outputArea.append(System.lineSeparator());
                new RemoteData().retrieve("root", ipText.getText());
                new LocalData().write(new LocalData().read(), localFileText.getText());
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }).start();
    }//GEN-LAST:event_getDataBtnActionPerformed

    private void plotBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_plotBtnActionPerformed
        try {
            double[] data = new PlotData().getData(userText.getText(), ipText.getText());
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_plotBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Main().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton applyBtn;
    private javax.swing.JButton chooseBtn;
    public static javax.swing.JCheckBox customBtn;
    public static javax.swing.JTextField customText;
    public static javax.swing.JTextField dacAText;
    public static javax.swing.JTextField dacBText;
    private javax.swing.JLabel dacHelp;
    private javax.swing.JLabel fileHelp;
    private javax.swing.JLabel frequencyHelp;
    public static javax.swing.JButton getDataBtn;
    public static javax.swing.JTextField ipText;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JLabel liaHelp;
    public static javax.swing.JTextField localFileText;
    private javax.swing.JLabel modAmpHelp;
    public static javax.swing.JTextField modAmpText;
    private javax.swing.JLabel modeHelp;
    public static javax.swing.JTextField modeText;
    public static javax.swing.JTextArea outputArea;
    public static javax.swing.JPasswordField passText;
    private javax.swing.JLabel phaseHelp;
    public static javax.swing.JTextField phaseText;
    private javax.swing.JButton plotBtn;
    private javax.swing.JComboBox<String> presetBox;
    public static javax.swing.JCheckBox presetBtn;
    private javax.swing.JLabel rateHelp;
    public static javax.swing.JTextField rateText;
    private javax.swing.JLabel sweepHelp;
    public static javax.swing.JTextField tSweepText;
    private javax.swing.JLabel tcHelp;
    public static javax.swing.JTextField tcText;
    public static javax.swing.JTextField userText;
    public static javax.swing.JTextField vStartText;
    public static javax.swing.JTextField vStopText;
    // End of variables declaration//GEN-END:variables
}
