/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liacontrol;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author stimp
 */
public class PlotData {

    public double[] getData(String user, String host) throws IOException {
        int ok = new RemoteData().retrieve(user, host);
        if (ok == 1) {
            int written = new LocalData().write(new LocalData().read(), "plottingdata.csv");
            if (written == 1) {
                System.out.println("Plotting data!");
                BufferedReader br = new BufferedReader(new FileReader("plottingdata.csv"));
                int i = 0;
                double[] data = new double[70000000];
                System.out.println("Reading...");
                try {
                    //StringBuilder sb = new StringBuilder();
                    String line = br.readLine();

                    while (line != null) {
                        //sb.append(line);
                        //sb.append(System.lineSeparator());
                        data[i] = Double.parseDouble(line);
                        i++;
                        line = br.readLine();
                        
                    }
                    //String everything = sb.toString();
                } finally {
                    br.close();
                System.out.println("Data read!");
                }
                System.out.println("Requesting chart...");
                new ChartBuilder().build(data);
            }
        }
        return null;
    }

}
