/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liacontrol;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

/**
 *
 * @author stimp
 */
public class LocalData {

    public String read() throws IOException {
        Main.outputArea.append("Reading");
        Main.outputArea.append(System.lineSeparator());
        // create FileInputStream object;
        byte[] bytes = getByte("remdata.lid");
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (int k = 0; k < bytes.length - 8; k = k + 8) {
            try {
                byte[] subarray = Arrays.copyOfRange(bytes, k, k + 7);
                //for (int i = 0; i < subarray.length; i++) {
                Object obj = ByteBuffer.wrap(subarray).order(ByteOrder.LITTLE_ENDIAN).getInt();
                if (!obj.getClass().equals(String.class)) {
                    int val = (Integer) obj;
                    if (val < 1676245) {
                        sb.append(Integer.toString(val));
                        sb.append(System.lineSeparator());
                    }
                } else {
                    Main.outputArea.append(obj.toString());
                    Main.outputArea.append(System.lineSeparator());
                }
                n++;
            } catch (Exception e) {
                Main.outputArea.append("Buffer underflow");
                Main.outputArea.append(System.lineSeparator());
            }
            //}
        }

        Main.outputArea.append("Read");
        Main.outputArea.append(System.lineSeparator());
        return sb.toString();
    }

    public int write(String data, String outfile) throws IOException {
        Main.outputArea.append("Writing");
        Main.outputArea.append(System.lineSeparator());

        FileWriter fw = new FileWriter(new File(outfile), false);

        fw.write(data);

        fw.close();

        Main.outputArea.append("Written");
        Main.outputArea.append(System.lineSeparator());
        return 1;
    }

    private byte[] getByte(String path) {
        byte[] getBytes = {};
        try {
            File file = new File(path);
            getBytes = new byte[(int) file.length()];
            InputStream is = new FileInputStream(file);
            is.read(getBytes);
            is.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return getBytes;
    }

}
