/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liacontrol;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author stimp
 */
public class Config {

    public void save(String ip, String user, String pass, String f, String t, String m, String vStart, String vStop, String tSweep, String a, String da, String db, String p, String r, String savefile) throws IOException {
        FileWriter fw = new FileWriter(new File("config.cfg"));
        fw.write(ip);
        fw.write(System.lineSeparator());
        fw.write(user);
        fw.write(System.lineSeparator());
        fw.write(pass);
        fw.write(System.lineSeparator());
        fw.write(f);
        fw.write(System.lineSeparator());
        fw.write(t);
        fw.write(System.lineSeparator());
        fw.write(m);
        fw.write(System.lineSeparator());
        fw.write(vStart);
        fw.write(System.lineSeparator());
        fw.write(vStop);
        fw.write(System.lineSeparator());
        fw.write(tSweep);
        fw.write(System.lineSeparator());
        fw.write(a);
        fw.write(System.lineSeparator());
        fw.write(da);
        fw.write(System.lineSeparator());
        fw.write(db);
        fw.write(System.lineSeparator());
        fw.write(p);
        fw.write(System.lineSeparator());
        fw.write(r);
        fw.write(System.lineSeparator());
        fw.write(savefile);
        fw.write(System.lineSeparator());
        fw.close();
    }

    public void read() throws FileNotFoundException, IOException {
        if (new File("config.cfg").exists()) {
            File file = new File("config.cfg");

            BufferedReader br = new BufferedReader(new FileReader(file));
            
            String line;
            String[] st = new String[1400];
            int i = 0;
            while ((line = br.readLine()) != null) {
                st[i] = line;
                i++;
            }
            Main.ipText.setText(st[0]);
            Main.userText.setText(st[1]);
            Main.passText.setText(st[2]);
            Main.customText.setText(st[3]);
            Main.customBtn.setSelected(true);
            Main.presetBtn.setSelected(false);
            Main.tcText.setText(st[4]);
            String[] mx = st[5].split("");
            String m = "";
            for(int k = mx.length-1; k >-1; k--){
                m = m + mx[k];
            }
            Main.modeText.setText(m);
            Main.vStartText.setText(st[6]);
            Main.vStopText.setText(st[7]);
            Main.tSweepText.setText(st[8]);
            Main.modAmpText.setText(st[9]);
            Main.dacAText.setText(st[10]);
            Main.dacBText.setText(st[11]);
            Main.phaseText.setText(st[12]);
            Main.rateText.setText(st[13]);
            if(!st[14].equals("")){
                Main.localFileText.setText(st[14]);
                Main.getDataBtn.setEnabled(true);
            }
            
        }
    }

}
