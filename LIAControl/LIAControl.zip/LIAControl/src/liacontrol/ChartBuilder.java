/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liacontrol;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class ChartBuilder {

    public void build(double[] data) throws IOException {
        try {
            System.out.println("Creating chart...");
            XYSeries series1 = new XYSeries("Channel 1");
            for (int i = 0; i < data.length; i = i + 50) {
                series1.add(i, data[i] / 2.1e6);
            }

// Add the series to your data set
            XYSeriesCollection dataset = new XYSeriesCollection();
            dataset.addSeries(series1);
            System.out.println("Dataset populated");

// Generate the graph
            JFreeChart chart = ChartFactory.createXYLineChart(
                    "STEMlab 125-14 LIA Output Plot", // Title
                    "Sample", // x-axis Label
                    "Signal (mV)", // y-axis Label
                    dataset, // Dataset
                    PlotOrientation.VERTICAL, // Plot Orientation
                    false, // Show Legend
                    true, // Use tooltips
                    false // Configure chart to generate URLs?
            );
            XYPlot xyPlot = chart.getXYPlot();
            XYItemRenderer xyir = xyPlot.getRenderer();
//            xyir.setSeriesStroke(0, new BasicStroke(Envy.linewidth));
//            xyir.setSeriesStroke(1, new BasicStroke(Envy.linewidth));
//            xyir.setSeriesPaint(0, Envy.ch1colour);
//            xyir.setSeriesPaint(1, Envy.ch2colour);
            xyPlot.getDomainAxis().setTickLabelsVisible(false);

            //chart.getPlot().setBackgroundPaint(Envy.bgColour);
            chart.getPlot().setOutlinePaint(Color.BLACK);

            //GUI.plottingPanel.setLayout(new java.awt.BorderLayout());
            //GUI.plottingPanel.removeAll();
            System.out.println("Displaying!");
            JFrame plotFrame = new JFrame("Plotting Window");
            ChartPanel chartPanel = new ChartPanel(chart);
            JPanel plotPanel = new JPanel();
            plotFrame.add(plotPanel);
            plotPanel.add(chartPanel, BorderLayout.CENTER);
            plotFrame.setBounds(10, 10, 720, 450);
            plotFrame.setVisible(true);
            //GUI.plottingPanel.revalidate();
        } catch (NullPointerException e) {
            System.out.println("Whoopsie!");
        }
    }
}
